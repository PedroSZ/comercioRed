
    <?php
    	if(isset($_SESSION['user'])) //echo "->".$_SESSION['user'];
    ?>
<nav class="navbar" style="background-color: rgba(173, 130, 37, 0.2);" data-bs-theme="light">
 <a class="navbar-brand" href="#">
    <img id ="logotipo" src="img/Logotipo.png" height="100" width="100"/>
</nav>