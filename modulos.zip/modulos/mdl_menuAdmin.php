<nav class="navbar navbar-expand-lg bg-body-tertiary">
  


<ul class='menu'>
     
    <li class='nav-item dropdown'>
      <a class='nav-link dropdown-toggle1' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>
      </a>
      <ul class='dropdown-menu'>

      </ul>
    </li>
<!--
    <li class='nav-item dropdown'>
      <a class='dropdown-item' onclick="activarModulo('NuevaVenta')">Nueva Venta</a>
    </li>

-->

    <li class='nav-item dropdown'>
      <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>
        Registrar
      </a>
      <ul class='dropdown-menu'>
        
         <li><a class='dropdown-item'  href="nuevoUsuario.php">Usuarios</a></li>
        <li><a class='dropdown-item'   href="nuevoProducto.php">Productos</a></li>
         <li><a class='dropdown-item'  href="nuevoCliente.php">Clientes</a></li>
         <li><a class='dropdown-item' title="" href="nuevaVenta.php">Ventas</a></li>
       
      </ul>
    </li>

     <li class='nav-item dropdown'>
      <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>
        Consultar
      </a>
      <ul class='dropdown-menu'>
         <li><a class='dropdown-item' href="listUsuarios.php">Usuarios</a></li>
         <li><a class='dropdown-item' href="listProductos.php">Productos</a></li>
         <li><a class='dropdown-item' href="listClientes.php">Clientes</a></li>
         <li><a class='dropdown-item' href="listVentas.php">Ventas</a></li>
       
      </ul>
    </li>



      <li class='nav-item dropdown'>
          <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>
            Modificar
          </a>
          <ul class='dropdown-menu'>
         <li><a class='dropdown-item'  href="listActualizarUsuarios.php">Usuarios</a></li>
         <li><a class='dropdown-item'  href="listActualizarProductos.php">Productos</a></li>
         <li><a class='dropdown-item'  href="listActualizarClientes.php">Clientes</a></li>
         <li><a class='dropdown-item'  href="actualizarVenta.php">Ventas</a></li>
          </ul>
        </li>


        <li class='nav-item dropdown'>
        <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>
          Eliminar
        </a>
        <ul class='dropdown-menu'>
          <li><a class='dropdown-item' href="listEliminarUsuarios.php">Usuarios</a></li>
        <li><a class='dropdown-item' href="listEliminarproductos.php">Productos</a></li>
         <li><a class='dropdown-item' href="listEliminarClientes.php">Clientes</a></li>
         <li><a class='dropdown-item' onclick="#">Ventas</a></li>
        </ul>
      </li>

       <li class='nav-item dropdown'>
        <a class='dropdown-item' href="actualizarInventario.php">Inventario</a>
        
      </li>

          <li class='nav-item dropdown'>
        <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>
          Salir
        </a>
        <ul class='dropdown-menu'>
          
          <li><a class='dropdown-item' href="modulos/mdl_logout.php">Serrar Sesión</a></li>
        </ul>
      </li>




    </ul>


 
</nav>