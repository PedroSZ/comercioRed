<nav class="navbar navbar-expand-lg bg-body-tertiary">
  


<ul class='menu'>
     
    <li class='nav-item dropdown'>
      <a class='nav-link dropdown-toggle1' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>
      </a>
      <ul class='dropdown-menu'>

      </ul>
    </li>
<!--
    <li class='nav-item dropdown'>
      <a class='dropdown-item' onclick="activarModulo('NuevaVenta')">Nueva Venta</a>
    </li>

-->

    <li class='dropdown-item'>
     <li><a class='dropdown-item' title="" href="nuevaVenta.php">Ventas</a></li>
    </li>

     <li class='dropdown-item'>
      <a class='dropdown-item' onclick="#">Consultar</a>
    </li>



      <li class='nav-item dropdown'>
        <a class='dropdown-item' href="actualizarInventario.php">Inventario</a>
        </li>


        <li class='nav-item dropdown'>
         <a class='dropdown-item' onclick="#">Eliminar</a>
        </li>

          <li class='nav-item dropdown'>
        <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>
          Salir
        </a>
        <ul class='dropdown-menu'>
          
          <li><a class='dropdown-item' href="modulos/mdl_logout.php">Serrar Sesión</a></li>
        </ul>
      </li>


    </ul>


 
</nav>