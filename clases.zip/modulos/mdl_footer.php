
<footer class="text-center text-white fixed-bottom" style="background-color:rgb(173, 130, 37);">
  <p>La Piconeria de Ameca<br>
    Av. Patria No. , Colonia Santuario, C.P. 46620. Ameca, Jal. <br>
    <b>Tel: 375 100 3330. lapiconeria@gmail.com</p>
    
</footer>