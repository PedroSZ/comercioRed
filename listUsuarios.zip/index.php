
</!DOCTYPE html>
<html lang="es">
<!-- INDEX.PHP -->
	<head>
	 	<title>LA PICONERIA</title>
		<meta name="viewport" content="width=device-width, initialscale=1" />
		<link rel="shortcut icon" href="img/icono.ico" />

	 	<style type="text/css">
			html, body, div, iframe {
				margin:0;
				padding:0;
				

			}
			/*IFRAME PARA OCULTAR URL*/
			iframe {
				display:block;
				width:100%;
				height:100%;
				border:none;
			}

		</style>
	</head>
	<body>
	 	<iframe src="login.php"></iframe>

	</body>
</html>