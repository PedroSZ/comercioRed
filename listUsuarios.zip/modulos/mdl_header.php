
    <?php
    	if(isset($_SESSION['user'])) //echo "->".$_SESSION['user'];
    ?>
<nav class="navbar ">
 <a class="navbar-brand" href="#">
    <img id ="logotipo" src="img/Logotipo.png"/>
    </a>
</nav>